<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<?php
	$t = "privet vasia<br>";
	$a = "t";
	echo $$a;
	$t = "kolia<br>";
	echo $$a;
	
	
	
	?>
</body>
</html>