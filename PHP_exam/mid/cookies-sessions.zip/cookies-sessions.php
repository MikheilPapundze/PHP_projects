<?php
session_start();
$a1 = array("ge", "en", "ru", "tr");

if (isset($_GET["lang"]))
{
	if (in_array($_GET["lang"],$a1))
	{
		$lang_def = $_GET["lang"];
	}
	else
	{
		$lang_def = "ge";
	}
	$time = time()+15*86400;
	setcookie("language", $lang_def, $time, "/");
}

 
 $user_db = "misho";
 $pass_db = "qwerty";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
<a href="?lang=ge"> GEO </a> | <a href="?lang=en"> ENG </a> | <a href="?lang=ru"> RUS </a> | <a href="?lang=tr"> TUR </a> 
	<hr>
<?php
	$_SESSION["logout"]="yes";
	echo "<form name='form1' method='post' action='cookies-sessions.php'>";
		
	if (isset($_COOKIE["language"]) && $_COOKIE["language"] == "ge")
	{
		echo "სახელი: <input type='text' name='name'><br>";
		echo "პაროლი: <input type='password' name='password'><br>";
		echo "<input type='submit' name='submit' value='შესვლა'>";
	}
	
	if (isset($_COOKIE["language"]) && $_COOKIE["language"] == "en")
	{
		echo "name: <input type='text' name='name'><br>";
		echo "password: <input type='password' name='password'><br>";
		echo "<input type='submit' name='submit'  value='login'>";
	}
	
	if (isset($_COOKIE["language"]) && $_COOKIE["language"] == "ru")
	{
		echo "фамилия: <input type='text' name='name'><br>";
		echo "пароль: <input type='password' name='password'><br>";
		echo "<input type='submit' name='submit'  value='авторизоваться'>";
	}
	
	if (isset($_COOKIE["language"]) && $_COOKIE["language"] == "tr")
	{
		echo "isim: <input type='text' name='name'><br>";
		echo "parola: <input type='password' name='password'><br>";
		echo "<input type='submit' name='submit'  value='oturum aç'>";
	}
	echo "</form>";
	
	if (isset($_POST['submit']))
	{
		if (isset($_SESSION["logout"]) && $_SESSION["logout"] == "yes")
		{
			$user = $_POST["name"];
			if ($_POST['name'] == $user_db && $_POST['password'] == $pass_db)
			{
				$_SESSION["login"] = "yes";
				$_POST['name']= $user;
			}
			else
			{
				if (isset($_COOKIE["language"]) && $_COOKIE["language"] == "ge")
				{
					echo "<div> სახელი ან პაროლი არასწორია </div>";
				}
				if (isset($_COOKIE["language"]) && $_COOKIE["language"] == "en")
				{
					echo "<div> Name or Password is incorrect </div>";
				}
				if (isset($_COOKIE["language"]) && $_COOKIE["language"] == "ru")
				{
					echo "<div> имя или пароль неверныა  </div>";
				}
				if (isset($_COOKIE["language"]) && $_COOKIE["language"] == "tr")
				{
					echo "<div> isim veya şifre yanlış  </div>";
				}
			}
		}
	}
	
	if (isset($_SESSION["login"]) && $_SESSION["login"] == "yes")
	{
		 if (isset($_COOKIE["language"]) && $_COOKIE["language"] == "ge")
		 {
			 echo "<div> მოგესალმებით <b>" . $user_db . "</b> </div><br>";
		     echo "<a href='?login=no'>გასვლა</a>";
		 }
		
		if (isset($_COOKIE["language"]) && $_COOKIE["language"] == "en")
		 {
			 echo "<div> hello <b>" . $user_db . "</b> </div><br>";
		     echo "<a href='?login=no'>logout</a>";
		 }
		
		if (isset($_COOKIE["language"]) && $_COOKIE["language"] == "ru")
		 {
			 echo "<div> Привет <b>" . $user_db . "</b> </div><br>";;
		     echo "<a href='?login=no'>выйти</a>";
		 }
		
		if (isset($_COOKIE["language"]) && $_COOKIE["language"] == "tr")
		 {
			 echo "<div> Merhaba <b>" . $user_db . "</b> </div><br>";;
		     echo "<a href='?login=no'>çıkış Yap</a>";
		 }				      
	}
	
?>
</body>
</html>